package com.bookstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookstore.entity.Book;
import com.bookstore.repository.BookStoreRepository;

@Service
public class BookStoreServiceImpl implements BookStoreService {
	@Autowired
	private BookStoreRepository bookRepository;

	public List<Book> getAllBooks() {
		return bookRepository.findAll();
	}

	public Book getBookById(Long id) {
		return bookRepository.findById(id).orElseThrow(() -> new RuntimeException("Book not found!"));
	}

	public Book saveBook(Book book) {
			return bookRepository.save(book);

	}

	public void deleteBook(Long id) {
		bookRepository.deleteById(id);
	}
}