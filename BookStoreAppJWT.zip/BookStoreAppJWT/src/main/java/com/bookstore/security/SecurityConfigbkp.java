//package com.bookstore.security;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.web.SecurityFilterChain;
//
//@Configuration
//public class SecurityConfigbkp {
//	@SuppressWarnings("removal")
//	@Bean
//	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//		http.csrf().disable().headers(headers -> headers.frameOptions().disable())
//				.authorizeHttpRequests(auth -> auth
//						.requestMatchers("/BookStoreApp/h2-console/**", "/BookStoreApp/swagger-ui/**",
//								"/BookStoreApp/v3/api-docs/**", "/BookStoreApp/api/**")
//						.permitAll().anyRequest().authenticated())
//				.httpBasic();
//		return http.build();
//	}
//}
